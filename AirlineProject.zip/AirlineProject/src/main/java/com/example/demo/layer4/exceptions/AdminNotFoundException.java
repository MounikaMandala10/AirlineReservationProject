package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class AdminNotFoundException extends Exception {
	public AdminNotFoundException(String msg) {
		super(msg);
	}
           
}
