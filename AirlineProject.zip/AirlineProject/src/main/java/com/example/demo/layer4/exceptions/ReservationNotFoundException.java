package com.example.demo.layer4.exceptions;

@SuppressWarnings("serial")
public class ReservationNotFoundException extends Exception {
	public  ReservationNotFoundException(String msg) {
		super(msg);
	}
	
}
