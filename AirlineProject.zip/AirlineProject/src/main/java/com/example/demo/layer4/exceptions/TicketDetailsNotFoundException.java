package com.example.demo.layer4.exceptions;
@SuppressWarnings("serial")
public class TicketDetailsNotFoundException extends Exception {
	public TicketDetailsNotFoundException(String msg) {
		super(msg);
	}
}
