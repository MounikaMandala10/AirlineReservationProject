import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlightSelectComponent } from './flight-select/flight-select.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';



@NgModule({
  declarations: [
    FlightSelectComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule
  ]
})
export class SelectModule { }
