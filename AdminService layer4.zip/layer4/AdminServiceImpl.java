package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Admin;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer4.exceptions.AdminAlreadyExistsException;
import com.example.demo.layer4.exceptions.AdminNotFoundException;

public class AdminServiceImpl implements AdminService
{

	@Autowired
	AdminRepository adminRepo;

	@Override
	public String addAdmin(Admin aRef)  throws AdminAlreadyExistsException {
		try {
			adminRepo.addAdmin(aRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			 throw new AdminAlreadyExistsException("Admin already exists");
		}
				return "Admin already exists";
	}

	@Override
	public Admin findAdmin(int adminid) throws AdminNotFoundException {
		try {
			return adminRepo.findAdmin(adminid);
		} catch (Exception e) {
			throw new AdminNotFoundException("Admin not found");	
		}
		}

	@Override
	public Set<Admin> findAdmin() {
		
		return adminRepo.findAdmin();
	}

	@Override
	public String modifyAdmin(Admin aRef) throws AdminNotFoundException{
		Admin a= adminRepo.findAdmin(aRef.getAdminid());
		if(a!=null)
		{
			adminRepo.modifyAdmin(aRef);
		}
		else
		{
			throw new AdminNotFoundException("admin not found");
		}
	
				return "admin not found";
	}

	@Override
	public String removeAdmin(int adminid) throws AdminNotFoundException {
		Admin a= adminRepo.findAdmin(adminid);
		if(a!=null)
		{
			adminRepo.removeAdmin(a.getAdminid());
		}
		else
		{
			throw new AdminNotFoundException("admin not found");
		}
	
			return "admin not found";
	}
	
}
	