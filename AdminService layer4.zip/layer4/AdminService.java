package com.example.demo.layer4;

import java.util.Set;

import com.example.demo.layer2.Admin;
import com.example.demo.layer4.exceptions.AdminAlreadyExistsException;
import com.example.demo.layer4.exceptions.AdminNotFoundException;

public interface AdminService {
	String addAdmin(Admin aRef) throws AdminAlreadyExistsException;   
	Admin findAdmin(int adminid) throws AdminNotFoundException;     
	Set<Admin> findAdmin();     
	String modifyAdmin(Admin aRef) throws AdminNotFoundException; 
	String removeAdmin(int adminid) throws AdminNotFoundException;


}
